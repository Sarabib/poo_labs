/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.laboratorio2;

/**
 *
 * @author xsraws
 */
public class Usuario {
    // atributos
    private String nombre;
    private long id;
    private Fecha fecha_nacimiento;
    private String ciudad_nacimiento;
    private long tel; 
    private String email;
    private Direccion dir;
    
    // constructores
    public Usuario(){}
    public Usuario(String n, long id){
        this.nombre = n;
        this.id = id;
    }
    
    // métodos set
    public void setNombre(String n){this.nombre = n;}
    public void setId(long id){this.id = id;}
    public void setFecha_nacimiento(Fecha f){this.fecha_nacimiento = f;}
    public void setCiudad_nacimiento(String c){this.ciudad_nacimiento = c;}
    public void setTel(long t){this.tel = t;}
    public void setEmail(String e){this.email = e;}
    public void setDir(Direccion d){this.dir = d;}
    
    // métodos get
    public String getNombre(){return nombre;}
    public long getId(){return id;}
    public Fecha getFecha_nacimiento(){return fecha_nacimiento;}
    public String getCiudad_nacimiento(){return ciudad_nacimiento;}
    public long getTel(){return tel;}
    public String getEmail(){return email;}
    public Direccion getDireccion(){return dir;}
    
    // toString
    public String toString(){
        return "Nombre: " + nombre + "\n" +
                "Id: " + id + "\n" +
                "Fecha nacimiento: " + fecha_nacimiento + "\n" +
                "Ciudad nacimiento: " + ciudad_nacimiento + "\n" +
                "Tel: " + tel + "\n" +
                "Email: " + email + "\n" +
                "Dirección: " + dir;
    }
    
    
    
    
}
