class Reserva():
    def __init__(self, titular, vuelo, numPasajeros):
        self.__numReserva = 0
        self.__pasajeros = [None] * numPasajeros
        self.__vuelo = vuelo
        self.__titular = titular

    @property
    def numReserva(self): return self.__numReserva

    @property
    def vuelo(self): return self.__vuelo

    @property
    def titular(self): return self.__titular

    @numReserva.setter
    def numReserva(self, num): self.__numReserva = num 

    def añadirPasajeros():
        # como se va a recibir la info de los pasajeros? entry o textbox?
        return
    
    