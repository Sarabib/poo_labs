from Usuario import *
from Vuelo import *

class Sistema():
    def __init__(self):
        self.__usuarios = []
        self.__vuelos = []

    def buscarUsuario(self, id):
        for i in self.__usuarios:
            if i.id == id:
                return self.__usuarios.index(i)
        return -1 
    
    def userEtiqueta(self, id):
        idx = self.buscarUsuario(id)
        if idx != -1:
            print(self.__usuarios[idx].etiqueta)
            return self.__usuarios[idx].etiqueta
        else:
            return None
            
    def registrarUsuario(self, nom, correo, id, cont, et):
        if nom == "" or id == "" or correo == "" or cont == "" or et == "":
            return False
        else:
            if et == "admin":
                nuevo = Admin(nom, id)
            else:
                nuevo = Cliente(nom, id)

            nuevo.correo = correo
            nuevo.contraseña = cont
            nuevo.etiqueta = et
            self.__usuarios.append(nuevo)
            return True
        
    def leerUsuarios(self, filename):
        try:
            with open(filename, "r", encoding="utf-8") as archive:
                lineas = archive.readlines()

                for linea in lineas:
                    datos = linea.split(",")
                    self.registrarUsuario(datos[0], datos[1], datos[2], datos[3], datos[4])
        except Exception as e:
            print(f"Error: {e}")
            return False

            
    def logIn(self, id, contraseña):
        if id == "": return False
        idx = self.buscarUsuario(id)
        if  idx == -1:
            print("incorrect id")
            return False
        return self.__usuarios[idx].contraseña == contraseña
        
    def buscarVueloCiudad(self, origen, destino):
       for i in self.__vuelos:
           if i.origen == origen and i.destino == destino:
               self.mostrarVuelo(self.__vuelos.index(i))
           else:
               continue
         
    
    def buscarVueloCod(self, codigo):
        for i in self.__vuelos:
            if i.codigo == codigo:
                return self.__vuelos.index(i)
        return -1
    
    def mostrarVuelo(self, idx):
        print(self.__vuelos[idx].__str__())
        return self.__vuelos[idx].__str__()
        
            
    def crearVuelo(self, cod, ori, des, dia, hor, pref, eco):
        if cod == "" or ori == "" or des == "" or dia == "" or hor == "" or pref == "" or eco =="":
            return False
        else:
            nuevo = Vuelo(cod)
            nuevo.origen = ori
            nuevo.destino = des
            nuevo.dia = dia
            nuevo.horario = hor
            nuevo.sillasPref = int(pref)
            nuevo.sillasEco = int(eco)
            self.__vuelos.append(nuevo)
            return True
            
    def leerVuelos(self, filename):
        try:
            with open(filename, "r", encoding="utf-8") as archive:
                lineas = archive.readlines()

                for linea in lineas:
                    datos = linea.strip().split()
                    self.crearVuelo(datos[0], datos[1], datos[2], datos[3], datos[4], int(datos[5]), int(datos[6]))
                return True
        except Exception as e:
            print(f"Error: {e}")
            return False

    def editarVuelo(self, codigo, propiedad, nuevo):
        if Sistema.buscarVueloCod(codigo) == - 1:
            return False 
        else:
            #analizar cadena de if-else?
            return 1
    
    def sillasDisponibles(self, codigo):
        idx = self.buscarVueloCod(codigo) 
        if idx == - 1:
            return -1, -1
        else:
            return self.__vuelos[idx].sillasPref, self.__vuelos[idx].sillasEco
        
    


