class Equipaje():
    def __init__(self):
        self._pesoMax = 0.
        self._peso = 0.
        self._idPasajero = 0

class DeMano(Equipaje):
    def __init__(self):
        super().__init__()

class Cabina(Equipaje):
    def __init__(self):
        super().__init__()

class Bodega(Equipaje):
    def __init__(self):
        super().__init__()