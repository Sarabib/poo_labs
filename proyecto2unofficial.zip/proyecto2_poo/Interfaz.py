from tkinter import *
from BasePage import *
from MenuAdminPage import*

class mainWindow(Tk):
    def __init__(self, sis):
        super().__init__()
        self.__sistema = sis

        self.title("Sistema Aerolínea")
        self.geometry("500x500")
        self.configure(bg="#F2E0E2")
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.loginPage = LoginPage(self, sis)
        self.registroPage = RegistroPage(self, sis)
        self.menuAdminPage = MenuAdminPage(self, sis)
        #menuClientePage = Frame(self)
        

        self.__pages  = {"loginPage": self.loginPage, "registroPage": self.registroPage,
                         "menuAdminPage" : self.menuAdminPage}
        for p in self.__pages.values():
            p.grid(row=0, column=0, sticky="news")

        self.mostrarPage("loginPage")        

    def mostrarPage(self, nombre):
        frame = self.__pages[nombre]
        frame.tkraise()



                 
            
            

        

    
