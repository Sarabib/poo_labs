from tkinter import *
import tkinter as tk
from tkinter import messagebox, font, ttk

class BasePage(Frame):
    def __init__(self, master, sis):
        super().__init__(master)
        self._master = master
        self._sistema = sis
        self.configure(bg="#F2E0E2")
        self._color1 = "#F85AA9"
        self._color2 = "#A37089"

        self.grid_columnconfigure(0, weight=1) 
        self.grid_columnconfigure(3, weight=1)
        self.grid_rowconfigure(0, weight=1)

class LoginPage(BasePage):
    def __init__(self, master, sis):
        super().__init__(master, sis)
        self.grid_rowconfigure(0, weight=0)

        #Widgets
        self.__loginLabel = Label(self, text="Login", bg="#F2E0E2", 
                                  fg=self._color1, font=("Arial", 20), pady=30)
        self.__loginLabel.grid(row=1, column=1, columnspan=2, sticky="news")
        
        self.__idLabel = Label(self, text="ID", bg="#F2E0E2", font=("Arial", 12), pady=15)
        self.__idLabel.grid(row=2, column=1) 

        self.__idEntry = Entry(self, font=("Arial", 12))
        self.__idEntry.grid(row=2, column=2)
        
        self.__contraLabel = Label(self, text="Contraseña", bg="#F2E0E2", 
                                   font=("Arial", 12), pady=15)
        self.__contraLabel.grid(row=3, column=1)

        self.__contraLabel.grid(row=3, column=1)
        
        self.__contraEntry = Entry(self, show="*", font=("Arial", 12))
        self.__contraEntry.grid(row=3, column=2)
            
        self.__loginButton = Button(self, text="Login", bg=self._color1, 
                                    font=("Arial", 14), pady=10, command=self.login)
        self.__loginButton.grid(row=4, column=1, columnspan=2)

        self.__questionLabel = Label(self, text="¿Aún no tienes una cuenta?",
                                     bg="#F2E0E2", font=("Arial", 10), pady=10)
        self.__questionLabel.grid(row=5, column=1, columnspan= 2)

        self.__registroButton = Button(self, text="Registro", bg=self._color1, 
                                       font=("Arial", 14), pady=10, 
                                       command=lambda: master.mostrarPage("registroPage"))
        self.__registroButton.grid(row=6, column=1, columnspan=2)

    def login(self):
        id = self.__idEntry.get() 
        contraseña = self.__contraEntry.get()
        etiqueta = self._sistema.userEtiqueta(id)
        if(self._sistema.logIn(id, contraseña)):
            print("log in correcto")
            if etiqueta == "admin":
                self._master.mostrarPage("menuAdminPage")
            else:
                print("agregar menu cliente")
        else:
            messagebox.showerror(title="Error", message="Login inválido")

class RegistroPage(BasePage):
        def __init__(self, master, sis):
            super().__init__(master, sis)
            self.grid_rowconfigure(0, weight=0)

            # Widgets
            self.__topLabel = Label(self, text="Ingrese sus datos", bg="#F2E0E2", 
                                    fg=self._color1, font=("Arial", 20), pady=30)
            self.__topLabel.grid(row=1, column=1, columnspan=2, sticky="news")
            
            self.__nomLabel = Label(self, text="Nombre", bg="#F2E0E2", 
                                    font=("Arial", 12), pady=15)
            self.__nomLabel.grid(row=2, column=1)
            self.__nomEntry = Entry(self, font=("Arial", 12))
            self.__nomEntry.grid(row=2, column=2)
            
            self.__correoLabel = Label(self, text="Correo", bg="#F2E0E2", 
                                       font=("Arial", 12), pady=15)
            self.__correoLabel.grid(row=3, column=1)
            self.__correoEntry = Entry(self, font=("Arial", 12))
            self.__correoEntry.grid(row=3, column=2)
            
            self.__idLabel = Label(self, text="ID", bg="#F2E0E2", 
                                   font=("Arial", 12), pady=15)
            self.__idLabel.grid(row=4, column=1)
            self.__idEntry = Entry(self, font=("Arial", 12))
            self.__idEntry.grid(row=4, column=2)
            
            self.__contraLabel = Label(self, text="Contraseña", bg="#F2E0E2", 
                                       font=("Arial", 12), pady=15)
            self.__contraLabel.grid(row=5, column=1)
            self.__contraEntry = Entry(self, font=("Arial", 12))
            self.__contraEntry.grid(row=5, column=2)
            
            self.__registroButton = Button(self, text="Registrar",  bg=self._color1, 
                                           font=("Arial", 14), pady=10, command=self.registro)
            self.__registroButton.grid(row=6, column=1, columnspan=2)

        def registro(self):
            nom = self.__nomEntry.get()
            correo = self.__correoEntry.get()
            id = self.__idEntry.get()
            contra = self.__contraEntry.get()
            if not self._sistema.registrarUsuario(nom, correo, id, contra, "cliente"):
                messagebox.showerror(title="Error", message="Por favor rellena todos los campos")
            else:
                self._master.mostrarPage("loginPage")
                messagebox.showinfo(title=":)", message="Registro Completado")
'''
class MenuAdminPage(BasePage):
     def __init__(self, master, sis):
        super().__init__(master, sis)

        self.grid_rowconfigure(0, weight=0)  # Fila del headFrame
        self.grid_rowconfigure(2, weight=1) # Fila content frame

        self.headFrame=Frame(self, bg=self._color1)
        self.headFrame.grid(row=0, column=0, sticky="EW")
        self.headFrame.configure(height=50)

        self.buscarVueloB = Button(self.headFrame, text="Buscar vuelo", 
                                   bg=self._color1, font=("Bold",10), 
                                   activebackground="#F2E0E2",
                                   command=lambda:self.cambiarMenu("buscarVuelo"))
        self.buscarVueloB.pack(side=tk.LEFT)

        self.agregarB = Button(self.headFrame, text="Agregar vuelo", 
                               bg=self._color1, font=("Bold",10), 
                               activebackground="#F2E0E2",
                               command=lambda:self.cambiarMenu("agregarVuelo"))
        self.agregarB.pack(side=tk.LEFT)

        self.editarB = Button(self.headFrame, text="Editar vuelo", 
                              bg=self._color1, font=("Bold",10), 
                              activebackground="#F2E0E2",
                              command=lambda:self.cambiarMenu("editarVuelo"))
        
        self.editarB.pack(side=tk.LEFT)

        self.sillasB = Button(self.headFrame, text="Consultar sillas", 
                              bg=self._color1, font=("Bold",10), 
                              activebackground="#F2E0E2")
        self.sillasB.pack(side=tk.LEFT)

        self.agregarUserB = Button(self.headFrame, text="Agregar usuario", 
                                   bg=self._color1, font=("Bold",10), 
                                   activebackground="#F2E0E2")
        self.agregarUserB.pack(side=tk.LEFT)

        self.buscarUserB = Button(self.headFrame, text="Buscar usuario", 
                                  bg=self._color1, font=("Bold",10), 
                                  activebackground="#F2E0E2")
        self.buscarUserB.pack(side=tk.LEFT)

        self.contentFrame = Frame(self, bg="#F2E0E2")
        self.contentFrame.grid(row=2, column=0, sticky="news")

        self.codEntry = None 
        self.infoVuelo_text = None

        

     def cambiarMenu(self, page):
        if page == "buscarVuelo":
            self.buscarVueloB.configure(bg=self._color1)
            self.agregarB.configure(bg=self._color2)
            self.editarB.configure(bg=self._color2)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.buscarVueloPage()

        elif page == "agregarVuelo":
            self.buscarVueloB.configure(bg=self._color2)
            self.agregarB.configure(bg=self._color1)
            self.editarB.configure(bg=self._color2)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.agregarVueloPage()

        elif page == "editarVuelo":
            self.buscarVueloB.configure(bg=self._color2)
            self.agregarB.configure(bg=self._color2)
            self.editarB.configure(bg=self._color1)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.editarVueloPage()
        else:
            self._vuelos.configure(bg="#F85AA9")
            self._usersB.configure(bg="#A37089")
    
        
     def buscarVueloPage(self):
        print("buscar Vuelo")

        for widget in self.contentFrame.winfo_children():
            widget.destroy()

        self.contentFrame.grid_columnconfigure(0, weight=1)
        self.contentFrame.grid_columnconfigure(4, weight=1)

        self.textBuscar = Label(self.contentFrame, text="Código de vuelo", 
                                bg="#F2E0E2", font=("Arial",12), pady=30)
        self.textBuscar.grid(row=1, column=1, padx= 5)
        
        self.codEntry = Entry(self.contentFrame, font=("Arial", 12))
        self.codEntry.grid(row=1, column=2, sticky="ew")

        self.buscarB = Button(self.contentFrame, text="Buscar", bg=self._color1, 
                              font=("Bold",10), activebackground="#F2E0E2", 
                              command=self.buscarVuelo)
        self.buscarB.grid(row=1, column=3, padx=5)

        self.infoVuelo_text = Text(self.contentFrame, wrap="word", bg="#FFFFFF", 
                                   height=10, width=50)
        
        self.infoVuelo_text.grid(row=2, column=1, columnspan=3, pady=20, padx=10, sticky="news")
        
        # Configuraciones de fuente
        self.fuenteNegrita = font.Font(family="Arial", size=12, weight="bold")
        self.infoVuelo_text.tag_configure("bold_tag", font=self.fuenteNegrita, foreground="black")
        self.infoVuelo_text.tag_configure("error_tag", foreground="red")

    
     def buscarVuelo(self):
          codigo = self.codEntry.get()
          print(f"Buscando vuelo con código: {codigo}")

          #Limpiar el cuadro de texto 
          self.infoVuelo_text.config(state=tk.NORMAL) 
          self.infoVuelo_text.delete('1.0', tk.END)

          vueloEncontrado = self._sistema.buscarVueloCod(codigo)
          if vueloEncontrado == -1 or vueloEncontrado is None:
            print("Vuelo no encontrado.")
            self.infoVuelo_text.insert('end', "¡Vuelo no encontrado!", "error_tag")
          else:
            print(f"Vuelo encontrado: {vueloEncontrado}")
            info = f"¡Vuelo encontrado!\n{self._sistema.mostrarVuelo(vueloEncontrado)}"
            self.infoVuelo_text.insert('end', info, "bold_tag")
            
          self.infoVuelo_text.config(state=tk.DISABLED)
          
     def agregarVueloPage(self):
         print("Agregar Vuelo")

         for widget in self.contentFrame.winfo_children():
            widget.destroy()

         self.contentFrame.grid_columnconfigure(0, weight=1)
         self.contentFrame.grid_columnconfigure(4, weight=1)

         self.infoLabel = Label(self.contentFrame, text="Información del vuelo",
                               bg="#F2E0E2", font=("Arial",12), pady=30)
         self.infoLabel.grid(row=1, column=1, padx=10)

         self.codLabel = Label(self.contentFrame, text="Código de vuelo",
                               bg="#F2E0E2", font=("Arial",12))
         self.codLabel.grid(row=2, column=1, padx=10)

         self.codEntry = Entry(self.contentFrame, font=("Arial",12))
         self.codEntry.grid(row=3, column=1, padx=10)
         
         self.origenLabel = Label(self.contentFrame, text="Ciudad origen",
                               bg="#F2E0E2", font=("Arial",12))
         self.origenLabel.grid(row=2, column=2, padx=10)
         

         self.origenEntry = Entry(self.contentFrame, font=("Arial",12))
         self.origenEntry.grid(row=3, column=2, padx=10)
         
         self.destinoLabel = Label(self.contentFrame, text="Ciudad destino",
                               bg="#F2E0E2", font=("Arial",12))
         self.destinoLabel.grid(row=2, column=3, padx=10)

         self.destinoEntry = Entry(self.contentFrame, font=("Arial",12))
         self.destinoEntry.grid(row=3, column=3, padx=10)


         self.diaLabel = Label(self.contentFrame, text="Día del vuelo",
                               bg="#F2E0E2", font=("Arial",12))
         self.diaLabel.grid(row=4, column=1, padx=10)
         

         self.diaEntry = Entry(self.contentFrame, font=("Arial",12))
         self.diaEntry.grid(row=5, column=1, padx=10)

         self.horarioLabel = Label(self.contentFrame, text="Horario del vuelo",
                               bg="#F2E0E2", font=("Arial",12))
         self.horarioLabel.grid(row=4, column=2, padx=10)
         

         self.horarioEntry = Entry(self.contentFrame, font=("Arial",12))
         self.horarioEntry.grid(row=5, column=2, padx=10)

         self.sillasPrefLabel = Label(self.contentFrame, text="Sillas Preferenciales",
                               bg="#F2E0E2", font=("Arial",12))
         self.sillasPrefLabel.grid(row=6, column=1, padx=10)
         

         self.sillasPrefEntry = Entry(self.contentFrame, font=("Arial",12))
         self.sillasPrefEntry.grid(row=7, column=1, padx=10)

         self.sillasEcoLabel = Label(self.contentFrame, text="Sillas Ecónomicas",
                               bg="#F2E0E2", font=("Arial",12))
         self.sillasEcoLabel.grid(row=6, column=2, padx=10)
         

         self.sillasEcoEntry = Entry(self.contentFrame, font=("Arial",12))
         self.sillasEcoEntry.grid(row=7, column=2, padx=10)

         self.agregarBtn = Button(self.contentFrame, text="Guardar", bg=self._color1, 
                              font=("Bold",10), activebackground="#F2E0E2", 
                              command=self.agregarVuelo)
         self.agregarBtn.grid(row=8, column=1, pady=20)
         
     def agregarVuelo(self):
         cod = self.codEntry.get()
         ori = self.origenEntry.get()
         des = self.destinoEntry.get()
         dia = self.diaEntry.get()
         hor = self.horarioEntry.get()
         pref = self.sillasPrefEntry.get()
         eco = self.sillasEcoEntry.get()

         if not self._sistema.crearVuelo(cod, ori, des, dia, hor, pref, eco):
            messagebox.showerror(title="Error", message="Por favor rellena todos los campos")
         elif not pref.isdigit() or not eco.isdigit():
             messagebox.showerror(title="Error", message="Ingrese solo números para las sillas")
         else:
            messagebox.showinfo(title=":)", message="Vuelo creado exitosamente")

     def editarVueloPage(self):
         print("Editar Vuelo")

         for widget in self.contentFrame.winfo_children():
            widget.destroy()

         self.contentFrame.grid_columnconfigure(0, weight=1)
         self.contentFrame.grid_columnconfigure(4, weight=1)

         self.codLabel = Label(self.contentFrame, text="Código de vuelo", 
                                bg="#F2E0E2", font=("Arial",12))
         self.codLabel.grid(row=0, column=1, padx= 5, pady=30)
        
         self.codEntry = Entry(self.contentFrame, font=("Arial", 12))
         self.codEntry.grid(row=0, column=2, sticky="ew")

         self.text = Label(self.contentFrame, text="Ingrese el nuevo valor", 
                                bg="#F2E0E2", font=("Arial",12))
         self.text.grid(row=2, column=1, padx= 5)

         self.propiedadCombobox = ttk.Combobox(self.contentFrame, 
                                            values=["Código", "Origen", "Destino",
                                                    "Día", "Horario", "Sillas Preferenciales",
                                                    "Sillas Ecónomicas"])
         self.propiedadCombobox.grid(row=2, column=2)
         '''