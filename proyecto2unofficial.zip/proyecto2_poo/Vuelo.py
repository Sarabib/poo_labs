class Vuelo():
    def __init__(self, codigo):
        self.__codigo = codigo
        self.__origen = None
        self.__destino = None
        self.__dia = None
        self.__horario = None
        self.__sillasPref = 0
        self.__sillasEco = 0
        self.__numPasajeros = self.__sillasPref + self.__sillasEco
        self.__reservasVuelo = [None]

    @property
    def codigo(self):
        return self.__codigo
    @property
    def origen(self):
        return self.__origen
    
    @property
    def destino(self):
        return self.__destino
    
    @property
    def dia(self):
        return self.__dia
    
    @property
    def horario(self):
        return self.__horario
    
    @property
    def sillasPref(self):
        return self.__sillasPref
    
    @property
    def sillasEco(self):
        return self.__sillasEco
    
    @origen.setter
    def origen(self, o):
        self.__origen = o
    
    @destino.setter
    def destino(self, d):
        self.__destino = d

    @dia.setter
    def dia(self, d):
        self.__dia = d

    @horario.setter
    def horario(self, h):
        self.__horario = h

    @sillasPref.setter
    def sillasPref(self, pref):
        self.__sillasPref = pref

    @sillasEco.setter
    def sillasEco(self, eco):
        self.__sillasEco = eco

    def __str__(self):
        return f"Código: {self.__codigo} \nOrigen: {self.__origen} Destino: {self.__destino}\nHorario: {self.__dia} {self.__horario}\nSillas Disponibles:\nPreferenciales: {self.__sillasPref}\nEconomicas: {self.__sillasEco}"

 