from Sistema import Sistema
from Interfaz import mainWindow

def main():
    sis = Sistema()  
    sis.registrarUsuario("J", "c", "1", "123", "admin")   
    sis.leerVuelos("vuelos.txt")
    sis.leerUsuarios("user.txt")
    aplicacion = mainWindow(sis) 
    aplicacion.mainloop()

if __name__ == "__main__":
    main()