from BasePage import * 
class MenuAdminPage(BasePage):
     def __init__(self, master, sis):
        super().__init__(master, sis)

        self.grid_rowconfigure(0, weight=0)  # Fila del headFrame
        self.grid_rowconfigure(2, weight=1) # Fila content frame

        self.headFrame=Frame(self, bg=self._color1)
        self.headFrame.grid(row=0, column=0, sticky="EW")
        self.headFrame.configure(height=50)

        self.buscarVueloB = Button(self.headFrame, text="Buscar vuelo", 
                                   bg=self._color1, font=("Bold",10), 
                                   activebackground="#F2E0E2",
                                   command=lambda:self.cambiarMenu("buscarVuelo"))
        self.buscarVueloB.pack(side=tk.LEFT)

        self.agregarB = Button(self.headFrame, text="Agregar vuelo", 
                               bg=self._color1, font=("Bold",10), 
                               activebackground="#F2E0E2",
                               command=lambda:self.cambiarMenu("agregarVuelo"))
        self.agregarB.pack(side=tk.LEFT)

        self.editarB = Button(self.headFrame, text="Editar vuelo", 
                              bg=self._color1, font=("Bold",10), 
                              activebackground="#F2E0E2",
                              command=lambda:self.cambiarMenu("editarVuelo"))
        
        self.editarB.pack(side=tk.LEFT)

        self.sillasB = Button(self.headFrame, text="Consultar sillas", 
                              bg=self._color1, font=("Bold",10), 
                              activebackground="#F2E0E2",
                              command=lambda:self.cambiarMenu("consultarSillas"))
        self.sillasB.pack(side=tk.LEFT)

        self.agregarUserB = Button(self.headFrame, text="Agregar usuario", 
                                   bg=self._color1, font=("Bold",10), 
                                   activebackground="#F2E0E2",
                                   command=lambda:self.cambiarMenu("agregarUser"))
        self.agregarUserB.pack(side=tk.LEFT)

        self.buscarUserB = Button(self.headFrame, text="Buscar usuario", 
                                  bg=self._color1, font=("Bold",10), 
                                  activebackground="#F2E0E2")
        self.buscarUserB.pack(side=tk.LEFT)

        self.contentFrame = Frame(self, bg="#F2E0E2")
        self.contentFrame.grid(row=2, column=0, sticky="news")

        self.codEntry = None 
        self.infoVueloText = None

        # Configuraciones de fuente
        self.fuenteNegrita = font.Font(family="Arial", size=12, weight="bold")
        

     def cambiarMenu(self, page):
        if page == "buscarVuelo":
            self.buscarVueloB.configure(bg=self._color1)
            self.agregarB.configure(bg=self._color2)
            self.editarB.configure(bg=self._color2)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.buscarVueloPage(page)

        elif page == "agregarVuelo":
            self.buscarVueloB.configure(bg=self._color2)
            self.agregarB.configure(bg=self._color1)
            self.editarB.configure(bg=self._color2)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.agregarVueloPage()

        elif page == "editarVuelo":
            self.buscarVueloB.configure(bg=self._color2)
            self.agregarB.configure(bg=self._color2)
            self.editarB.configure(bg=self._color1)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.editarVueloPage()

        elif page == "consultarSillas":
            self.buscarVueloB.configure(bg=self._color2)
            self.agregarB.configure(bg=self._color2)
            self.editarB.configure(bg=self._color2)
            self.sillasB.configure(bg=self._color1)
            self.agregarUserB.configure(bg=self._color2)
            self.buscarUserB.configure(bg=self._color2)

            self.buscarVueloPage(page)

        elif page == "agregarUser":
            self.buscarVueloB.configure(bg=self._color2)
            self.agregarB.configure(bg=self._color2)
            self.editarB.configure(bg=self._color2)
            self.sillasB.configure(bg=self._color2)
            self.agregarUserB.configure(bg=self._color1)
            self.buscarUserB.configure(bg=self._color2)

            self.agregarUserPage()
                
        else:
            self._vuelos.configure(bg="#F85AA9")
            self._usersB.configure(bg="#A37089")
    
        
     def buscarVueloPage(self, page):
        for widget in self.contentFrame.winfo_children():
            widget.destroy()

        self.contentFrame.grid_columnconfigure(0, weight=1)
        self.contentFrame.grid_columnconfigure(4, weight=1)

        self.textBuscar = Label(self.contentFrame, text="Código de vuelo", 
                                bg="#F2E0E2", font=("Arial",12), pady=30)
        self.textBuscar.grid(row=1, column=1, padx= 5)
        
        self.codEntry = Entry(self.contentFrame, font=("Arial", 12))
        self.codEntry.grid(row=1, column=2, sticky="ew")

        self.buscarB = Button(self.contentFrame, text="Buscar", bg=self._color1, 
                              font=("Bold",10), activebackground="#F2E0E2")
        self.buscarB.grid(row=1, column=3, padx=5)

        if page == "buscarVuelo":
            print("buscar vuelo")
            self.buscarB.config(command=self.buscarVuelo)
   
        else:
            self.buscarB.config(command=self.consultarSillas)
            print("sillas")

        self.infoVueloText = Text(self.contentFrame, wrap="word", bg="#FFFFFF", 
                                   height=10, width=50)
        self.infoVueloText.grid(row=2, column=1, columnspan=3, pady=20, padx=10, sticky="news")
        self.infoVueloText.tag_configure("bold_tag", font=self.fuenteNegrita, foreground="black")
        self.infoVueloText.tag_configure("error_tag", foreground="red")
    
     def buscarVuelo(self):
          codigo = self.codEntry.get()
          print(f"Buscando vuelo {codigo}")

          #Limpiar el cuadro de texto 
          self.infoVueloText.config(state=tk.NORMAL) 
          self.infoVueloText.delete('1.0', tk.END)

          vueloEncontrado = self._sistema.buscarVueloCod(codigo)
          if vueloEncontrado == -1 or vueloEncontrado is None:
            print("Vuelo no encontrado.")
            self.infoVueloText.insert('end', "¡Vuelo no encontrado!", "error_tag")
          else:
            print(f"Vuelo encontrado: {vueloEncontrado}")
            info = f"¡Vuelo encontrado!\n{self._sistema.mostrarVuelo(vueloEncontrado)}"
            self.infoVueloText.insert('end', info, "bold_tag")
            
          self.infoVueloText.config(state=tk.DISABLED)

     def consultarSillas(self):
         codigo = self.codEntry.get()
         print(f"Sillas para el vuelo {codigo}")

         self.infoVueloText.config(state=tk.NORMAL) 
         self.infoVueloText.delete('1.0', tk.END)

         sillasP, sillasE = self._sistema.sillasDisponibles(codigo)
         if sillasP == -1:
            print("Vuelo no encontrado.")
            self.infoVueloText.insert('end', "¡Vuelo no encontrado!", "error_tag")
         else:
            print(f"Vuelo encontrado: {codigo}")
            info = f"Sillas Disponibles para el vuelo {codigo}\nSillas Preferenciales: {sillasP}\nSillas Económicas: {sillasE}"
            self.infoVueloText.insert('end', info, "bold_tag")
            
         self.infoVueloText.config(state=tk.DISABLED)
          
     def agregarVueloPage(self):
         print("Agregar Vuelo")

         for widget in self.contentFrame.winfo_children():
            widget.destroy()

         self.contentFrame.grid_columnconfigure(0, weight=1)
         self.contentFrame.grid_columnconfigure(4, weight=1)

         self.infoLabel = Label(self.contentFrame, text="Información del vuelo",
                               bg="#F2E0E2", font=("Arial",12), pady=30)
         self.infoLabel.grid(row=1, column=1, padx=10)

         self.codLabel = Label(self.contentFrame, text="Código de vuelo",
                               bg="#F2E0E2", font=("Arial",12))
         self.codLabel.grid(row=2, column=1, padx=10)

         self.codEntry = Entry(self.contentFrame, font=("Arial",12))
         self.codEntry.grid(row=3, column=1, padx=10)
         
         self.origenLabel = Label(self.contentFrame, text="Ciudad origen",
                               bg="#F2E0E2", font=("Arial",12))
         self.origenLabel.grid(row=2, column=2, padx=10)
         

         self.origenEntry = Entry(self.contentFrame, font=("Arial",12))
         self.origenEntry.grid(row=3, column=2, padx=10)
         
         self.destinoLabel = Label(self.contentFrame, text="Ciudad destino",
                               bg="#F2E0E2", font=("Arial",12))
         self.destinoLabel.grid(row=2, column=3, padx=10)

         self.destinoEntry = Entry(self.contentFrame, font=("Arial",12))
         self.destinoEntry.grid(row=3, column=3, padx=10)


         self.diaLabel = Label(self.contentFrame, text="Día del vuelo",
                               bg="#F2E0E2", font=("Arial",12))
         self.diaLabel.grid(row=4, column=1, padx=10)
         

         self.diaEntry = Entry(self.contentFrame, font=("Arial",12))
         self.diaEntry.grid(row=5, column=1, padx=10)

         self.horarioLabel = Label(self.contentFrame, text="Horario del vuelo",
                               bg="#F2E0E2", font=("Arial",12))
         self.horarioLabel.grid(row=4, column=2, padx=10)
         

         self.horarioEntry = Entry(self.contentFrame, font=("Arial",12))
         self.horarioEntry.grid(row=5, column=2, padx=10)

         self.sillasPrefLabel = Label(self.contentFrame, text="Sillas Preferenciales",
                               bg="#F2E0E2", font=("Arial",12))
         self.sillasPrefLabel.grid(row=6, column=1, padx=10)
         

         self.sillasPrefEntry = Entry(self.contentFrame, font=("Arial",12))
         self.sillasPrefEntry.grid(row=7, column=1, padx=10)

         self.sillasEcoLabel = Label(self.contentFrame, text="Sillas Ecónomicas",
                               bg="#F2E0E2", font=("Arial",12))
         self.sillasEcoLabel.grid(row=6, column=2, padx=10)
         

         self.sillasEcoEntry = Entry(self.contentFrame, font=("Arial",12))
         self.sillasEcoEntry.grid(row=7, column=2, padx=10)

         self.agregarBtn = Button(self.contentFrame, text="Guardar", bg=self._color1, 
                              font=("Bold",10), activebackground="#F2E0E2", 
                              command=self.agregarVuelo)
         self.agregarBtn.grid(row=8, column=1, pady=20)
         
     def agregarVuelo(self):
         cod = self.codEntry.get()
         ori = self.origenEntry.get()
         des = self.destinoEntry.get()
         dia = self.diaEntry.get()
         hor = self.horarioEntry.get()
         pref = self.sillasPrefEntry.get()
         eco = self.sillasEcoEntry.get()

         if not self._sistema.crearVuelo(cod, ori, des, dia, hor, pref, eco):
            messagebox.showerror(title="Error", message="Por favor rellena todos los campos")
         elif not pref.isdigit() or not eco.isdigit():
             messagebox.showerror(title="Error", message="Ingrese solo números para las sillas")
         else:
            messagebox.showinfo(title=":)", message="Vuelo creado exitosamente")

     def editarVueloPage(self):
         print("Editar Vuelo")

         for widget in self.contentFrame.winfo_children():
            widget.destroy()

         self.contentFrame.grid_columnconfigure(0, weight=1)
         self.contentFrame.grid_columnconfigure(4, weight=1)

         self.codLabel = Label(self.contentFrame, text="Código de vuelo", 
                                bg="#F2E0E2", font=("Arial",12))
         self.codLabel.grid(row=0, column=1, padx= 5, pady=30)
        
         self.codEntry = Entry(self.contentFrame, font=("Arial", 12))
         self.codEntry.grid(row=0, column=2, sticky="ew")

         self.text = Label(self.contentFrame, text="Ingrese el nuevo valor", 
                                bg="#F2E0E2", font=("Arial",12))
         self.text.grid(row=2, column=1, padx= 5)

         self.propiedadCombobox = ttk.Combobox(self.contentFrame, 
                                            values=["Código", "Origen", "Destino",
                                                    "Día", "Horario", "Sillas Preferenciales",
                                                    "Sillas Ecónomicas"])
         self.propiedadCombobox.grid(row=3, column=1)

         self.nuevoEntry = Entry(self.contentFrame, font=("Arial", 12))
         self.nuevoEntry.grid(row=3, column=2, sticky="ew")

         self.editarBtn = Button(self.contentFrame, text="Cambiar", bg=self._color1, 
                              font=("Bold",10), activebackground="#F2E0E2", 
                              command=self.editarVuelo)
         self.editarBtn.grid(row=4, column=1)

     def editarVuelo(self):
          codigo = self.codEntry.get()
          print(f"Editando el vuelo {codigo}")
          propiedad = self.propiedadCombobox.get()
          nuevo = self.nuevoEntry.get()
          if not self._sistema.editarVuelo(codigo, propiedad, nuevo):
              messagebox.showerror(title="Error", message="Por favor rellena todos los campos")
          elif propiedad == ("Sillas Preferencailes" or propiedad == "Sillas Ecónomicas") and  not nuevo.isdigit:
              messagebox.showerror(title="Error", message="Ingresa solo números para las sillas") 
          else:
              messagebox.showinfo(title=":)", message=f"Vuelo {codigo} editado exitósamente") 

     def agregarUserPage(self):
         print("Agregar usuario")

         for widget in self.contentFrame.winfo_children():
            widget.destroy()

         self.contentFrame.grid_columnconfigure(0, weight=1)
         self.contentFrame.grid_columnconfigure(7, weight=1)

         self.infoLabel = Label(self.contentFrame, text="Información del usuario",
                               bg="#F2E0E2", font=("Arial",12), pady=30)
         self.infoLabel.grid(row=1, column=1, padx=10)

         self.rolCombobox = ttk.Combobox(self.contentFrame, 
                                            values=["Cliente", "Administrador"])
         self.rolCombobox.grid(row=1, column=2)

         self.nomLabel = Label(self.contentFrame, text="Nombre",
                               bg="#F2E0E2", font=("Arial",12))
         self.nomLabel.grid(row=2, column=1, padx=10)

         self.nomEntry = Entry(self.contentFrame, font=("Arial",12))
         self.nomEntry.grid(row=3, column=1, padx=10)
         
         self.docLabel = Label(self.contentFrame, text="Documento de identidad",
                               bg="#F2E0E2", font=("Arial",12))
         self.docLabel.grid(row=2, column=2, padx=10)
         

         self.docEntry = Entry(self.contentFrame, font=("Arial",12))
         self.docEntry.grid(row=3, column=2, padx=10)
         
         self.correoLabel = Label(self.contentFrame, text="Correo",
                               bg="#F2E0E2", font=("Arial",12))
         self.correoLabel.grid(row=4, column=1, padx=10)

         self.correoEntry = Entry(self.contentFrame, font=("Arial",12))
         self.correoEntry.grid(row=5, column=1, padx=10)


         self.conLabel = Label(self.contentFrame, text="Contraseña(provisional)",
                               bg="#F2E0E2", font=("Arial",12))
         self.conLabel.grid(row=4, column=2, padx=10)
         
         self.conEntry = Entry(self.contentFrame, font=("Arial",12))
         self.conEntry.grid(row=5, column=2, padx=10)

         self.agregarBtn = Button(self.contentFrame, text="Guardar", bg=self._color1, 
                              font=("Bold",10), activebackground="#F2E0E2", 
                              command=self.agregarUser)
         self.agregarBtn.grid(row=6, column=1, pady=20)

     def agregarUser(self):
         nom = self.nomEntry.get()
         correo = self.correoEntry.get()
         doc = self.docEntry.get()
         cont = self.conEntry.get()
         et = self.rolCombobox.get()
         if not self._sistema.registrarUsuario(nom, correo, doc, cont, et):
                messagebox.showerror(title="Error", message="Por favor rellena todos los campos")
         else:
                messagebox.showinfo(title=":)", message="Registro Completado")



    