/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.laboratorio2;
import java.util.Scanner;
/**
 *
 * @author xsraws
 */
public class Laboratorio2 {

    public static void main(String[] args) {
        // A
        Fecha f1 = new Fecha(22, 12, 2006);
        System.out.println(f1);
        
        Direccion dir1 = new Direccion();
        dir1.setCalle("13");
        dir1.setNomenclatura("#44-85");
        dir1.setBarrio("La colinita");
        dir1.setCiudad("Medellín");
        dir1.setEdificio("Kiwii");
        dir1.setApto("2611");
        
        System.out.println(dir1);

        Usuario user = new Usuario("Juli", 1232142);
        user.setFecha_nacimiento(f1);
        user.setCiudad_nacimiento("Pasto");
        user.setTel(327163132);
        user.setEmail("sadacac@daa");
        user.setDir(dir1);
        
        System.out.println(user);
        
        // B
        Scanner esc = new Scanner(System.in);
        
        Fecha f2 = new Fecha();
        Direccion dir2 = new Direccion();
        Usuario user2 = new Usuario();
        
        System.out.println("Ingrese sus datos de usuario");
        
        System.out.println("Nombre: ");
        String n = esc.nextLine();
        user2.setNombre(n);
        
        System.out.println("Id: ");
        long id = esc.nextLong();
        user2.setId(id);
        
        System.out.println("Fecha nacimiento: ");
        System.out.println("Día: ");
        int dd = esc.nextInt();
        f2.setDia(dd);
        
        System.out.println("Mes: ");
        int mm = esc.nextInt();
        f2.setMes(mm);
        
        System.out.println("Año: ");
        int aa = esc.nextInt();
        f2.setA(aa);
        
        user2.setFecha_nacimiento(f2);
        esc.nextLine();
        
        System.out.println("Ciudad nacimiento: ");
        String ci = esc.nextLine();
        user2.setCiudad_nacimiento(ci);
        
        System.out.println("Tel: ");
        long t = esc.nextLong();
        user2.setTel(t);
        
        esc.nextLine();
        
        System.out.println("Email: ");
        String e = esc.nextLine();
        user2.setEmail(e);
        
        System.out.println("Ingrese su dirección: ");
        
        System.out.println("Calle: ");
        String c = esc.nextLine();
        dir2.setCalle(c);
        
        System.out.println("Nomenclatura: ");
        String no = esc.nextLine();
        dir2.setNomenclatura(no);
        
        System.out.println("Barrio: ");
        String b  = esc.nextLine();
        dir2.setBarrio(b);
        
        System.out.println("Ciudad: ");
        String ciudad = esc.nextLine();
        dir2.setCiudad(ciudad);
        
        System.out.println("Edificio: ");
        String ed = esc.nextLine();
        dir2.setEdificio(ed);
        
        System.out.println("Apto: ");
        String ap = esc.nextLine();
        dir2.setApto(ap);
        
        user2.setDir(dir2);
        
        System.out.println(user2);
    }
}
