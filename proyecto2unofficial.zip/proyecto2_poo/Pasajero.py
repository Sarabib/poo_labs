class Pasajero():
    def __init__(self, nom, id, silla):
        self.__nombre = nom
        self.__id = id
        self.__silla = silla
        self.__equipaje = [None]